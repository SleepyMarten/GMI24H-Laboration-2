using System;
using LaborationInterfaces;

//Namnge namespace med ditt namn. Till exempel: Duck_Donald
namespace Lastname_Firstname

{
    public class Laboration_2_ArrayList<TypeName> : ILaboration_2_List<TypeName> 
    {
    }
}
