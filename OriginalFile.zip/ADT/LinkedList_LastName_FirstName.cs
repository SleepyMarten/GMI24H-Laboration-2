﻿using System;
using System.Text;
using LaborationInterfaces;

//Namnge namespace med ditt namn. Till exempel: Duck_Donald
namespace Lastname_Firstname
{
    public class Laboration_2_LinkedList<TypeName> : ILaboration_2_List<TypeName>
    {
        /// <summary>
        /// Describes how a node in the list is constructed.
        /// A node contains:
        /// * Data (of any type) to be stored and handled in the list type
        /// * A reference to the next node in the list.
        /// </summary>
        internal class Node
        {
            internal TypeName Data { get; set; }
            internal Node Next { get; set; }
        }

        private readonly Node first;

        /// <summary>
        /// The constructor creates a dummy node, that acts as sentinel
        /// for the following nodes in the list.
        /// </summary>
        public Laboration_2_LinkedList()
        {
            // Här saknas kod
        }

        // Här måste du fylla på med kod.
    }
}
